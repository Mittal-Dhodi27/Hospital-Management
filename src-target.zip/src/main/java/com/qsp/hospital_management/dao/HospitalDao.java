package com.qsp.hospital_management.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qsp.hospital_management.dto.Hospital;
import com.qsp.hospital_management.repo.HospitalRepo;

@Repository
public class HospitalDao {

	@Autowired
	private HospitalRepo repo;
	
	public Hospital saveHospital(Hospital hospital) {
		return repo.save(hospital);
	}

	public Hospital getHospById(int id) {
		Optional<Hospital> optional=repo.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	public Hospital deleteHosp(int id) {
		Optional<Hospital> optional=repo.findById(id);
		if (optional.isEmpty()) {
			return null;
		}
		Hospital hospital=optional.get();
		repo.delete(hospital);
		return hospital;
	}

	public Hospital updateHospital(int id, Hospital hospital) {
		Optional<Hospital> optional=repo.findById(id);
		if (optional.isPresent()) {	
			hospital.setId(id);
			return repo.save(hospital);
		}
		return null;
	}

	public Hospital findByEmail(String email) {		
		
		return repo.findHospitalByEmail(email);
	}

	public List<Hospital> getAll() {	
		return repo.findAll();
	}
	
	
}
