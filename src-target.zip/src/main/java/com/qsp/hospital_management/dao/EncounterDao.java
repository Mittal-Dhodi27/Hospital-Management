package com.qsp.hospital_management.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qsp.hospital_management.dto.Encounter;
import com.qsp.hospital_management.dto.Hospital;
import com.qsp.hospital_management.repo.EncounterRepo;

@Repository
public class EncounterDao {

	@Autowired
	private EncounterRepo encounterRepo;
	
	public Encounter saveE(Encounter encounter) {
		return encounterRepo.save(encounter);
	}

	public Encounter findById(int id) {
		Optional<Encounter> optional=encounterRepo.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}
	
}
