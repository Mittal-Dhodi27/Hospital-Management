package com.qsp.hospital_management.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qsp.hospital_management.dto.Address;
import com.qsp.hospital_management.dto.Hospital;
import com.qsp.hospital_management.repo.AddressRepo;

@Repository
public class AddressDao {
	
	@Autowired
	private AddressRepo addressRepo;
	
	public Address saveAddress(Address address) {	
		return addressRepo.save(address);
	}

	public Address getAddrById(int id) {
		
		Optional<Address> optional=addressRepo.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	public Address deleteAddr(int id) {
		Optional<Address> optional=addressRepo.findById(id);
		if (optional.isEmpty()) {
			return null;
		}
		Address address=optional.get();
		addressRepo.delete(address);
		return address;
	}

	public Address updateAddress(int id, Address address) {
		Optional<Address> optional=addressRepo.findById(id);
		if (optional.isPresent()) {	
			address.setId(id);
			return addressRepo.save(address);
		}
		return null;
		
	}

}
