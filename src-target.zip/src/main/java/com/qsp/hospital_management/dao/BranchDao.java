package com.qsp.hospital_management.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qsp.hospital_management.dto.Address;
import com.qsp.hospital_management.dto.Branch;
import com.qsp.hospital_management.dto.Hospital;
import com.qsp.hospital_management.repo.BranchRepo;

@Repository
public class BranchDao {

	@Autowired
	private BranchRepo branchRepo;
	
	private HospitalDao hospitalDao;
	
	public Branch saveBranch(Branch branch) {
		return branchRepo.save(branch);
	}

	public Branch getBranchById(int id) {
		Optional<Branch> optional=branchRepo.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	public Branch deleteBranch(int id) {
		
		Optional<Branch> optional=branchRepo.findById(id);
		if (optional.isEmpty()) {
			return null;
		}
		Branch branch=optional.get();
		branchRepo.delete(branch);
		return branch;
	}

	public Branch updateBranch(int id, Branch branch) {
		Optional<Branch> optional=branchRepo.findById(id);
		if (optional.isPresent()) {	
			branch.setId(id);
			return branchRepo.save(branch);
		}
		return null;
	}

	

	
	
}
