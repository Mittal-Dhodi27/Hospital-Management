package com.qsp.hospital_management.dao;

import org.springframework.stereotype.Repository;

@Repository
public class MedItemDao {

}
