package com.qsp.hospital_management.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.qsp.hospital_management.dto.Person;
import com.qsp.hospital_management.service.PersonService;
import com.qsp.hospital_management.util.ResponseStructure;

@RestController
@RequestMapping("/person")
public class PersonController {

	@Autowired
	private PersonService personService;
	
	@PostMapping
	public ResponseStructure<Person> savePerson(@Valid @RequestBody Person person) {
		return personService.savePerson(person);				
	}
	
	@GetMapping
	public ResponseStructure<Person> findByID(int id) {
		return personService.findByID(id);
	}
	
	@PutMapping
	public ResponseStructure<Person> update(@RequestParam int id,@RequestBody Person person) {
		return personService.update(id,person);
	}
	
	@DeleteMapping
	public ResponseStructure<Person> deleteP(int id) {
		return personService.deleteP(id);
	}
	
	@GetMapping("/findPhone")
	public ResponseStructure<Person> findByPhone(@RequestParam long phone) {
		return personService.findByPhone(phone);
	}
	
}

