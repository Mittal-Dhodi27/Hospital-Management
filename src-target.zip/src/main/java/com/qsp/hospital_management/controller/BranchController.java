package com.qsp.hospital_management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.qsp.hospital_management.dto.Address;
import com.qsp.hospital_management.dto.Branch;
import com.qsp.hospital_management.service.BranchService;

@RestController
@RequestMapping("/branch")
public class BranchController {

	@Autowired
	private BranchService branchService;
	
	@PostMapping
	public Branch saveBranch(@RequestParam int hid,@RequestParam int aid,@RequestBody Branch branch) {
		return branchService.saveBranch(hid,aid,branch);
	}

	@GetMapping
	public Branch getBranchById(@RequestParam int id) {
		return branchService.getBranchById(id);
	}
	
	@DeleteMapping("/{id}")
	public Branch deleteBranch(@PathVariable int id) {
		return branchService.deleteBranch(id);
	}
	
	@PutMapping
	public Branch updateBranch(@RequestParam int id,@RequestBody Branch branch) {
		return branchService.updateBranch(id,branch);
	}
	
	

	
	
}
