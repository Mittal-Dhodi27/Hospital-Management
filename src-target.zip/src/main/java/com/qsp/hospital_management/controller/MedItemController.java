package com.qsp.hospital_management.controller;

public class MedItemController {

}
