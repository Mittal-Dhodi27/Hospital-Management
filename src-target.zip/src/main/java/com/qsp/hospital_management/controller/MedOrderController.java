package com.qsp.hospital_management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.qsp.hospital_management.dto.MedOrder;
import com.qsp.hospital_management.service.MedOrderService;

@RestController
@RequestMapping("/medorder")
public class MedOrderController {

	@Autowired
	private MedOrderService medOrderService;
	
//	@PostMapping
//	public MedOrder saveMO(@RequestParam int eid,@RequestBody MedOrder medOrder) {
//		return medOrderService.saveMO(eid,medOrder);
//	}
	
	
}
