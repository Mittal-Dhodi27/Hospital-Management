package com.qsp.hospital_management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.qsp.hospital_management.dto.Hospital;
import com.qsp.hospital_management.service.HospitalService;
import com.qsp.hospital_management.util.ResponseStructure;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@RestController
@RequestMapping("/hospital")
public class HospitalController {//find,delete,update,findByEmail

	@Autowired
	private HospitalService service;
	
	@ApiOperation(notes = "This api is used to save hospital data into database",value = "Save Hospital API")
	@ApiResponses(value = {@ApiResponse(code = 201,message = "Data Saved Successfully")})
	@PostMapping
	public ResponseEntity<ResponseStructure<Hospital>> saveHospital(@RequestBody Hospital hospital) {
		return service.saveHospital(hospital);
	}
	
	@GetMapping
	public ResponseEntity<ResponseStructure<Hospital>> getHospById(@RequestParam int id) {
		return service.getHospById(id);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<ResponseStructure<Hospital>> deleteHosp(@PathVariable int id) {
		return service.deleteHosp(id);
	}
	
	@PutMapping
	public ResponseEntity<ResponseStructure<Hospital>> updateHospital(@RequestParam int id,@RequestBody Hospital hospital) {
		return service.updateHospital(id,hospital);
	}
	
	@GetMapping("/email")
	public ResponseEntity<ResponseStructure<Hospital>> findByEmail(String email) {	
		return service.findByEmail(email);
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<ResponseStructure<List<Hospital>>> getAll() {
		return service.getAll();
	}
	
	
}
