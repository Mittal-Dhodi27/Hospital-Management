package com.qsp.hospital_management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.qsp.hospital_management.dto.Encounter;
import com.qsp.hospital_management.service.EncounterService;

@RestController
@RequestMapping("/encounter")
public class EncounterController {

	@Autowired
	private EncounterService encounterService;

	@PostMapping
	public Encounter saveE(@RequestBody Encounter encounter, int pid, int bid) {
		return encounterService.saveE(encounter, pid, bid);
	}
	
	@GetMapping
	public Encounter findById(@RequestParam int id) {
		return encounterService.findById(id);
	}
	
}
