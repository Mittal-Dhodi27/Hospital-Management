package com.qsp.hospital_management.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.qsp.hospital_management.dao.PersonDao;
import com.qsp.hospital_management.dto.Hospital;
import com.qsp.hospital_management.dto.Person;
import com.qsp.hospital_management.util.ResponseStructure;

@Service
public class PersonService {

	@Autowired
	private PersonDao personDao;
	
	public ResponseStructure<Person> savePerson(Person person) {		
		ResponseStructure<Person> structure = new ResponseStructure<Person>();
		structure.setMessage("Person saved Successfully");
		structure.setStatus(HttpStatus.CREATED.value());
		structure.setData(personDao.savePerson(person));

		return structure;
	}

	public ResponseStructure<Person> findByID(int id) {
		
		Person person= personDao.findByID(id);
		ResponseStructure<Person> structure = new ResponseStructure<Person>();

		if (person != null) {

			structure.setMessage("Person Found Successfully");
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setData(person);

			return structure;
		} else {
			structure.setMessage("Person Not Found...!");
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setData(person);
			return structure;
		}

		
	}

	public ResponseStructure<Person> update(int id, Person person) {
		
		Person p=personDao.update(id, person);
		ResponseStructure<Person> structure = new ResponseStructure<Person>();

		if (p != null) {

			structure.setMessage("Person update Successfully");
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setData(personDao.savePerson(person));

			return structure;
		} else {
			structure.setMessage("Person Not Found...!");
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setData(person);
			return structure;
		}
	}

	public ResponseStructure<Person> deleteP(int id) {
		
		Person person= personDao.deleteP(id);
		ResponseStructure<Person> structure = new ResponseStructure<Person>();

		if (person != null) {

			structure.setMessage("Person Delete Successfully");
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setData(person);

			return structure;
		} else {
			structure.setMessage("Person Not Found...!");
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setData(person);
			return structure;
		}
	}

	
	
	public ResponseStructure<Person> findByPhone(long phone) {
		Person person= personDao.findByPhone(phone);
		ResponseStructure<Person> structure = new ResponseStructure<Person>();
		if (person != null) {

			structure.setMessage("Person Found Successfully");
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setData(person);

			return structure;
		} else {
			structure.setMessage("Person Not Found...!");
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setData(person);
			return structure;
		}

	}	

}
