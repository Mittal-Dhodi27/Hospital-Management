package com.qsp.hospital_management.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qsp.hospital_management.dao.EncounterDao;
import com.qsp.hospital_management.dao.MedOrderDao;
import com.qsp.hospital_management.dto.MedOrder;

@Service
public class MedOrderService {

	@Autowired
	private MedOrderDao medOrderDao;
	
	@Autowired
	private EncounterDao encounterDao;

//	public MedOrder saveMO(int eid, MedOrder medOrder) {
//		encounterDao.
//	}

	

	
	
	

}
