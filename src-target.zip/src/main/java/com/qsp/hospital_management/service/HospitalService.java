package com.qsp.hospital_management.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.qsp.hospital_management.dao.HospitalDao;
import com.qsp.hospital_management.dto.Hospital;
import com.qsp.hospital_management.exception.IdNotFound;
import com.qsp.hospital_management.util.ResponseStructure;

@Service
public class HospitalService {

	@Autowired
	private HospitalDao dao;

	public ResponseEntity<ResponseStructure<Hospital>> saveHospital(Hospital hospital) {
		
		ResponseStructure<Hospital> structure = new ResponseStructure<Hospital>();
		structure.setMessage("Hospital saved Successfully");
		structure.setStatus(HttpStatus.CREATED.value());
		structure.setData(dao.saveHospital(hospital));

		return new ResponseEntity<ResponseStructure<Hospital>>(structure, HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<Hospital>> getHospById(int id) {

		Hospital hospital = dao.getHospById(id);
		ResponseStructure<Hospital> structure = new ResponseStructure<Hospital>();

		if (hospital != null) {

			structure.setMessage("Hospital Found Successfully");
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setData(hospital);

			return new ResponseEntity<ResponseStructure<Hospital>>(structure, HttpStatus.FOUND);
		} else {
			throw new IdNotFound("HOSPITAL WITH GIVEN ID NOT FOUND");
		}
	}

	public ResponseEntity<ResponseStructure<Hospital>> deleteHosp(int id) {

		Hospital hospital = dao.deleteHosp(id);
		ResponseStructure<Hospital> structure = new ResponseStructure<Hospital>();
		if (hospital != null) {

			structure.setMessage("Data Delete Successfully");
			structure.setStatus(HttpStatus.OK.value());
			structure.setData(hospital);

			return new ResponseEntity<ResponseStructure<Hospital>>(structure, HttpStatus.OK);
		} else {

			structure.setMessage("Hospital Data Not Found..!");
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setData(hospital);

			return new ResponseEntity<ResponseStructure<Hospital>>(structure, HttpStatus.NOT_FOUND);
		}

	}

	public ResponseEntity<ResponseStructure<Hospital>> updateHospital(int id, Hospital hospital) {
		ResponseStructure<Hospital> structure = new ResponseStructure<Hospital>();
		Hospital h = dao.updateHospital(id, hospital);
		if (h != null) {

			structure.setMessage("Hospital saved Successfully");
			structure.setStatus(HttpStatus.CREATED.value());
			structure.setData(dao.saveHospital(hospital));

			return new ResponseEntity<ResponseStructure<Hospital>>(structure, HttpStatus.CREATED);
		} else {
			structure.setMessage("No Data Present");
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setData(hospital);

			return new ResponseEntity<ResponseStructure<Hospital>>(structure, HttpStatus.NOT_FOUND);
		}
	}

	public ResponseEntity<ResponseStructure<Hospital>> findByEmail(String email) {

		Hospital hospital = dao.findByEmail(email);
		ResponseStructure<Hospital> structure = new ResponseStructure<Hospital>();
		if (hospital != null) {

			structure.setMessage("Data Found Successfully");
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setData(dao.saveHospital(hospital));

			return new ResponseEntity<ResponseStructure<Hospital>>(structure, HttpStatus.FOUND);
		} else {
			structure.setMessage("No Data Present");
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setData(hospital);

			return new ResponseEntity<ResponseStructure<Hospital>>(structure, HttpStatus.NOT_FOUND);
		}
	}

	public ResponseEntity<ResponseStructure<List<Hospital>>> getAll() {
		
		List<Hospital> list= dao.getAll();
		ResponseStructure<List<Hospital>> structure = new ResponseStructure<List<Hospital>>();
		if (list.isEmpty()) {
			structure.setMessage("Data Not Found");
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setData(list);

			return new ResponseEntity<ResponseStructure<List<Hospital>>>(HttpStatus.NOT_FOUND);
		} else {
			structure.setMessage("Data FOUND");
			structure.setStatus(HttpStatus.OK.value());
			structure.setData(list);

			return new ResponseEntity<ResponseStructure<List<Hospital>>>(HttpStatus.OK);
		}
	}

}
