package com.qsp.hospital_management.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.qsp.hospital_management.dao.AddressDao;
import com.qsp.hospital_management.dto.Address;
import com.qsp.hospital_management.dto.Hospital;
import com.qsp.hospital_management.util.ResponseStructure;

@Service
public class AddressService {

	@Autowired
	private AddressDao addressDao;
	
	public ResponseStructure<Address> saveAddress(Address address) {
		ResponseStructure<Address> structure = new ResponseStructure<Address>();
		structure.setMessage("Address saved Successfully");
		structure.setStatus(HttpStatus.CREATED.value());
		structure.setData(addressDao.saveAddress(address));

		return structure;
	}

	public ResponseStructure<Address> getAddrById(int id) {
		
		Address address=addressDao.getAddrById(id);
		ResponseStructure<Address> structure = new ResponseStructure<Address>();
		if (address != null) {
			structure.setMessage("Address Found Successfully");
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setData(address);

			return structure;
			
			
		}else {
			structure.setMessage("Address NOT Found..!");
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setData(address);

			return structure;
	
		}
	}

	public ResponseStructure<Address> deleteAddr(int id) {
		
		Address address=addressDao.deleteAddr(id);
		ResponseStructure<Address> structure = new ResponseStructure<Address>();
		if (address != null) {
			structure.setMessage("Address DELETE Successfully");
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setData(address);

			return structure;
			
			
		}else {
			structure.setMessage("Address NOT Found..!");
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setData(address);

			return structure;
	
		}
		
	}

	public ResponseStructure<Address> updateAddress(int id, Address address) {
		
		Address addr= addressDao.updateAddress(id,address);
		ResponseStructure<Address> structure = new ResponseStructure<Address>();
		if (address != null) {
			structure.setMessage("Address update Successfully");
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setData(addressDao.saveAddress(address));

			return structure;
			
			
		}else {
			structure.setMessage("Address NOT Found..!");
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setData(address);

			return structure;
	
		}

	}

	

}
