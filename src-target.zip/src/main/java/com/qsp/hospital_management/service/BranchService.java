package com.qsp.hospital_management.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qsp.hospital_management.dao.AddressDao;
import com.qsp.hospital_management.dao.BranchDao;
import com.qsp.hospital_management.dao.HospitalDao;
import com.qsp.hospital_management.dto.Address;
import com.qsp.hospital_management.dto.Branch;
import com.qsp.hospital_management.dto.Hospital;

@Service
public class BranchService {

	@Autowired
	private BranchDao branchDao;
	@Autowired
	private HospitalDao hospitalDao;
	@Autowired
	private AddressDao addressDao;
	
	public Branch saveBranch(int hid, int aid, Branch branch) {
		Hospital hospital=hospitalDao.getHospById(aid);
		Address address=addressDao.getAddrById(aid);
		if (hospital!=null && address!=null) {
			branch.setHospital(hospital);
			branch.setAddress(address);
			return branchDao.saveBranch(branch);
		}
		return null;
	}

	public Branch getBranchById(int id) {
		return branchDao.getBranchById(id);
		
	}

	public Branch deleteBranch(int id) {
		
		return branchDao.deleteBranch(id);
	}

	public Branch updateBranch(int id, Branch branch) {
		
		return branchDao.updateBranch(id,branch);
	}

	
	

}
