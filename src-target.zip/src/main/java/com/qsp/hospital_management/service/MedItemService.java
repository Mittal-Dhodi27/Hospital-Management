package com.qsp.hospital_management.service;

public class MedItemService {

}
