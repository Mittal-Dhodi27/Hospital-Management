package com.qsp.hospital_management.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qsp.hospital_management.dao.BranchDao;
import com.qsp.hospital_management.dao.EncounterDao;
import com.qsp.hospital_management.dao.PersonDao;
import com.qsp.hospital_management.dto.Branch;
import com.qsp.hospital_management.dto.Encounter;
import com.qsp.hospital_management.dto.Person;

import net.bytebuddy.asm.Advice.Return;

@Service
public class EncounterService {

	@Autowired
	private EncounterDao encounterDao;
	
	@Autowired
	private PersonDao personDao;
	
	@Autowired
	private BranchDao branchDao;

	public Encounter saveE(Encounter encounter, int pid, int bid) {
		Person person=personDao.findByID(pid);
		Branch branch=branchDao.getBranchById(bid);
		if (person!=null && branch!=null) {
			encounter.setPerson(person);
			List<Branch> list=new ArrayList<Branch>();
			list.add(branch);
			encounter.setBranchs(list);
			return encounterDao.saveE(encounter);
		}
		
		return null;
	}

	public Encounter findById(int id) {
		
		return encounterDao.findById(id);
	}

}
