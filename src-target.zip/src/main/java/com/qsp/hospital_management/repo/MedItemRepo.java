package com.qsp.hospital_management.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qsp.hospital_management.dto.MedItem;

public interface MedItemRepo extends JpaRepository<MedItem, Integer> {

}
