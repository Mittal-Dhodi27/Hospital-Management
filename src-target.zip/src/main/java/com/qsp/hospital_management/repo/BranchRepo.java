package com.qsp.hospital_management.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qsp.hospital_management.dto.Branch;

public interface BranchRepo extends JpaRepository<Branch, Integer> {


	
}
